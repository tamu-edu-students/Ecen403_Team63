package com.example.awgv4

import android.os.Environment
import com.example.awgv4.FunctionList.convertDoubleToDACValue
import com.example.awgv4.FunctionList.dacToHex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.io.IOException

suspend fun writeToFile(fileName: String, downloadPoints: Array<Pair<Double, Double>>) {
    withContext(Dispatchers.IO) {
        val file = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            fileName
        )
        try {
            BufferedWriter(FileWriter(file)).use { bufferedWriter ->
                bufferedWriter.write("Time, Voltage, DAC Value, HEX Value\n")
                downloadPoints.forEach { (x,y) ->
                    val dacValue = convertDoubleToDACValue(y)
                    val hexValue = dacToHex(dacValue)
                    bufferedWriter.write("$x, $y, $dacValue, $hexValue\n")
                }
            }
        }
        catch (e:IOException) {
            // Handle file IO exception
            e.printStackTrace()
        }
    }
}