package com.example.awgv4

import androidx.annotation.StringRes
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType

const val MAX_CHAR = 6
const val MIN_FREQ = 1.0
const val MAX_FREQ = 20000.0
const val MIN_Y_VALUE = -10.0
const val MAX_Y_VALUE = 10.0
const val MIN_POINT = 10
const val MAX_POINT = 65535
const val TEXT_FIELD_WEIGHT = 1f
const val TEXT_FIELD_SPACER = 8
const val INVALID_AMP = 0.0
const val INVALID_NUM = -11.0

/**
 *  User Input Text Fields
 *  @param label : Title text shown on the field
 *  @param placeholder : Text shown when field is focused and input is empty
 *  @param value : The input text to be shown in the field
 *  @param onValueChange : When the Value Parameter Changes
 *  @param isError : Used to check for when an invalid input occurred
 *  @param modifier : The Modifier to be applied to the Field
 */
@ExperimentalMaterial3Api
@Composable
fun UserTextField(
    @StringRes label: Int,
    @StringRes placeholder: Int,
    value: String,
    onValueChange: (String) -> Unit,
    isError: Boolean,
    modifier: Modifier
) {
    val focusManager = LocalFocusManager.current    //Used for clearing focus on item

    TextField(
//Adjustable Values
        label = { Text(stringResource(label)) },
        placeholder = { Text(stringResource(placeholder)) },
        value = value.take(MAX_CHAR),
        onValueChange = onValueChange,
        isError = isError,
        modifier = modifier,
//New Default Parameters
        singleLine = true,
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number,
            imeAction = ImeAction.Done
        ),
        keyboardActions = KeyboardActions(
            onDone = { focusManager.clearFocus() }
        ),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
            unfocusedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
            focusedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
            unfocusedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
            focusedTextColor = MaterialTheme.colorScheme.onSecondaryContainer,
            unfocusedTextColor = MaterialTheme.colorScheme.onSecondaryContainer,
            errorContainerColor = MaterialTheme.colorScheme.errorContainer,
            errorLabelColor = MaterialTheme.colorScheme.onErrorContainer,
            errorTextColor = MaterialTheme.colorScheme.onErrorContainer
        )
    )
}

// Validates User Input
fun validateDouble(
    input: String,
    minValue: Double,
    maxValue: Double,
    excludedValue: Double
): Boolean {
    return if (input.toDoubleOrNull() == null) false
    else {
        val value = input.toDouble()
        if (value == excludedValue) {
            return false
        }
        val maxDecimal = 1
        val decimalSeparatorIndex = input.indexOf('.')

        // Check the number of decimal places
        val decimalPlaces = if (decimalSeparatorIndex == -1) 0 else {
            input.length - decimalSeparatorIndex - 1
        }
        val isValidDecimalPlaces = decimalPlaces <= maxDecimal

        // Check the range
        val isInRange = value in minValue..maxValue

        isValidDecimalPlaces && isInRange
    }
}

fun validateInt(input: String, minValue: Int, maxValue: Int): Boolean {
    return if (input.toIntOrNull() == null) false
    else input.toInt() in minValue..maxValue
}
