package com.example.awgv4.data.chat

import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

class BluetoothDataTransferService(
    private val socket: BluetoothSocket
) {
    suspend fun sendData(bytes: ByteArray): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                socket.outputStream.write(bytes)
                //Log.d("sendData", "Attempted data write to outputStream")
            } catch (e: IOException) {
                e.printStackTrace()
                //Log.d("sendData", "Failed to Send Data")
                return@withContext false
            }
            true
        }
    }
}