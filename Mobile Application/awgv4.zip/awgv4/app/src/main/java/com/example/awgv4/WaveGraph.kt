package com.example.awgv4

import android.content.res.Configuration
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import co.yml.charts.axis.AxisData
import co.yml.charts.common.model.Point
import co.yml.charts.ui.linechart.LineChart
import co.yml.charts.ui.linechart.model.GridLines
import co.yml.charts.ui.linechart.model.IntersectionPoint
import co.yml.charts.ui.linechart.model.Line
import co.yml.charts.ui.linechart.model.LineChartData
import co.yml.charts.ui.linechart.model.LinePlotData
import co.yml.charts.ui.linechart.model.LineStyle
import co.yml.charts.ui.linechart.model.LineType
import co.yml.charts.ui.linechart.model.ShadowUnderLine
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import kotlin.math.roundToInt

private const val X_LABEL_MILLI = 0.01
private const val X_LABEL_NANO = 0.00001
private const val X_AXIS_PADDING = 12
private const val Y_AXIS_PADDING = 24
private const val ALPHA_ON = 1f
private const val ALPHA_OFF = 0f

private const val LANDSCAPE_X_STEP_SIZE = 72
private const val LANDSCAPE_GRAPH_HEIGHT = 204
private const val LANDSCAPE_X_STEP = 10
private const val LANDSCAPE_Y_STEP = 4

private const val PORTRAIT_X_STEP_SIZE = 26
private const val PORTRAIT_GRAPH_HEIGHT = 620
private const val PORTRAIT_X_STEP = 5
private const val PORTRAIT_Y_STEP = 10

@Composable
fun WaveGraph(mode: Int, period: Double, pointsData : List<Point>) {
// Detect Current Screen Orientation
    val configuration = LocalConfiguration.current
    val xAxisStepSize: Int
    val graphHeight: Int
    val xStep: Int
    val yStep: Int

// Check Phone Orientation
    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            xAxisStepSize = LANDSCAPE_X_STEP_SIZE
            graphHeight = LANDSCAPE_GRAPH_HEIGHT
            xStep = LANDSCAPE_X_STEP
            yStep = LANDSCAPE_Y_STEP
        }
        else -> {
            xAxisStepSize = PORTRAIT_X_STEP_SIZE
            graphHeight = PORTRAIT_GRAPH_HEIGHT
            xStep = PORTRAIT_X_STEP
            yStep = PORTRAIT_Y_STEP
        }
    }

// Detect which WaveType is Active
    val isLineEnabled: Float
    val isIntersectionEnabled: Float
    val isShadowEnabled: Float
    if (mode == R.string.freehand) {
        isLineEnabled = ALPHA_OFF
        isIntersectionEnabled = ALPHA_OFF
        isShadowEnabled = ALPHA_OFF
    } else {
        isLineEnabled = ALPHA_ON
        isIntersectionEnabled = ALPHA_ON
        isShadowEnabled = ALPHA_ON/2
    }

// Determine X-Label
    val xScale: Double = if (period > 0.001) X_LABEL_MILLI else X_LABEL_NANO

// Data used to generate X axis
    val xAxisData = AxisData.Builder()
        .axisStepSize(xAxisStepSize.dp)
        .steps(xStep)
        .startDrawPadding(1.dp)
        .backgroundColor(Color.Transparent)
        .labelAndAxisLinePadding(X_AXIS_PADDING.dp)
        .labelData { i ->
            val xLabel = (period / xScale).toFloat()
            (i * xLabel).formatToSinglePrecision()
        }
        //.labelData { i -> i.toString() }
        .axisLineColor(MaterialTheme.colorScheme.tertiary)
        .axisLabelColor(MaterialTheme.colorScheme.tertiary)
        .shouldDrawAxisLineTillEnd(true)
        .build()

// Data used to generate Y axis
    val yAxisData = AxisData.Builder()
        .steps(yStep)
        .backgroundColor(Color.Transparent)
        .labelAndAxisLinePadding(Y_AXIS_PADDING.dp)
        .labelData { i ->
            val yMin = pointsData.minOf { it.y }
            val yMax = pointsData.maxOf { it.y }
            val yScale = (yMax - yMin) / yStep
            ((i * yScale) + yMin).formatToDoublePrecision()
        }
        .axisLineColor(MaterialTheme.colorScheme.tertiary)
        .axisLabelColor(MaterialTheme.colorScheme.tertiary)
        .build()

// Line Displayed on Graph
    val lineChartData = LineChartData(
        linePlotData = LinePlotData(
            lines = listOf(
                Line(
                    dataPoints = pointsData,
                    LineStyle(
                        color = MaterialTheme.colorScheme.tertiary,
                        lineType = LineType.Straight(isDotted = true),
                        width = 4f,
                        alpha = isLineEnabled
                    ),
                    IntersectionPoint(
                        color = MaterialTheme.colorScheme.tertiary,
                        radius = 4.dp,
                        alpha = isIntersectionEnabled
                    ),
                    selectionHighlightPoint = null,
                    ShadowUnderLine(
                        alpha = isShadowEnabled,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.inversePrimary,
                                Color.Transparent
                            )
                        )
                    ),
                    selectionHighlightPopUp = null
                )
            ),
        ),
        backgroundColor = MaterialTheme.colorScheme.surface,
        xAxisData = xAxisData,
        yAxisData = yAxisData,
        gridLines = GridLines(
            color = MaterialTheme.colorScheme.outlineVariant,
            enableVerticalLines = false
        )
    )

// Produces Graph
    LineChart(
        modifier = Modifier
            .fillMaxWidth()
            .height(graphHeight.dp),
        lineChartData = lineChartData
    )
}

//fun Float.formatToDoublePrecision(): String = DecimalFormat("#.##").format(this)

fun Float.formatToSinglePrecision(): String {
    val roundedValue = (this * 10).roundToInt() / 10.0
    return DecimalFormat("#.#").format(roundedValue)
}

fun Float.formatToDoublePrecision(): String {
    val roundedValue = BigDecimal(this.toString()).setScale(2, RoundingMode.HALF_UP)
    return roundedValue.toString()
}

fun Modifier.vertical() =
    layout { measurable, constraints ->
        val placeable = measurable.measure(constraints)
        layout(placeable.height, placeable.width) {
            placeable.place(
                x = -(placeable.width / 2 - placeable.height / 2),
                y = -(placeable.height / 2 - placeable.width / 2)
            )
        }
    }