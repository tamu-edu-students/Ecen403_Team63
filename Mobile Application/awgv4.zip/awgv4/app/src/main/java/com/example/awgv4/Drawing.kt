package com.example.awgv4

import android.content.res.Configuration
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.*

private const val PORTRAIT_CANVAS_X_OFFSET = -27//-45
private const val PORTRAIT_CANVAS_Y_OFFSET = 25
private const val PORTRAIT_CANVAS_WIDTH = 265
private const val PORTRAIT_CANVAS_HEIGHT = 560

private const val LANDSCAPE_CANVAS_X_OFFSET = -16//-35
private const val LANDSCAPE_CANVAS_Y_OFFSET = 25
private const val LANDSCAPE_CANVAS_WIDTH = 730
private const val LANDSCAPE_CANVAS_HEIGHT = 145

const val PORTRAIT_X_START_BOUND = 10f
const val PORTRAIT_Y_START_BOUND = 10f
const val PORTRAIT_X_END_BOUND = 700f
const val PORTRAIT_Y_END_BOUND = 1460f

const val LANDSCAPE_X_START_BOUND = 15f
const val LANDSCAPE_Y_START_BOUND = 15f
const val LANDSCAPE_X_END_BOUND = 1905f
const val LANDSCAPE_Y_END_BOUND = 370f

private const val MAX_LINE_LENGTH = 20f

@Composable
fun drawFunction(clear: Boolean, configuration: Configuration):List<Line> {
    val path = remember { Path() }
    val lines = remember { mutableStateListOf<Line>() }
    val lineColor = MaterialTheme.colorScheme.tertiary

// Boundary Parameters
    val xStartBound: Float
    val xEndBound: Float
    val yStartBound: Float
    val yEndBound: Float

    val canvasWidth: Int
    val canvasHeight: Int
    val canvasXOffset: Int
    val canvasYOffset: Int

// Check Phone Orientation
    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            canvasWidth = LANDSCAPE_CANVAS_WIDTH; canvasHeight = LANDSCAPE_CANVAS_HEIGHT
            canvasXOffset = LANDSCAPE_CANVAS_X_OFFSET; canvasYOffset = LANDSCAPE_CANVAS_Y_OFFSET
            xStartBound = LANDSCAPE_X_START_BOUND; xEndBound = LANDSCAPE_X_END_BOUND
            yStartBound = LANDSCAPE_Y_START_BOUND; yEndBound = LANDSCAPE_Y_END_BOUND
        }
        else -> { canvasWidth = PORTRAIT_CANVAS_WIDTH; canvasHeight = PORTRAIT_CANVAS_HEIGHT
            canvasXOffset = PORTRAIT_CANVAS_X_OFFSET; canvasYOffset = PORTRAIT_CANVAS_Y_OFFSET
            xStartBound = PORTRAIT_X_START_BOUND; xEndBound = PORTRAIT_X_END_BOUND
            yStartBound = PORTRAIT_Y_START_BOUND; yEndBound = PORTRAIT_Y_END_BOUND
        }
    }

// Clear the canvas
    if (clear) { lines.clear() }

// Drawable Canvas
    Box(
        modifier = Modifier
            .offset(canvasXOffset.dp, canvasYOffset.dp)
            .width(canvasWidth.dp)
            .height(canvasHeight.dp)
            .background(Color.Transparent)
    )
    {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .clipToBounds()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val line = Line(
                            start = change.position - dragAmount,
                            end = change.position
                        )

                        // Calculate the original line length
                        val origLineLength = sqrt(dragAmount.x.pow(2)+dragAmount.y.pow(2))

                        // Check if the line length exceeds the maximum length
                        if (origLineLength > MAX_LINE_LENGTH) {
                            // Divide original line into segments, add each segment to lines list
                            val numSegments = (origLineLength / MAX_LINE_LENGTH).toInt()
                            for (i in 0 until numSegments) {
                                val startFraction = i.toFloat() / numSegments
                                val endFraction = (i + 1).toFloat() / numSegments

                                val segStart = line.start + (line.end - line.start) * startFraction
                                val segEnd = line.start + (line.end - line.start) * endFraction

                                val segment = Line(
                                    start = segStart,
                                    end = segEnd,
                                )
                                lines.add(segment)
                            }
                        } else {
                            lines.add(line)
                        }
                    }
                }
        ) {
            path.reset()
            lines.forEach { line ->
                path.moveTo(line.start.x, line.start.y)
                path.lineTo(line.end.x, line.end.y)
            }

            drawPath(
                path = path,
                color = lineColor,
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
        }
    }
    var i = 0
    while (i < lines.size) {
        if (!lineBound(xStartBound,xEndBound,yStartBound,yEndBound,lines[i])) {
            lines.remove(lines[i])
        }
        i++
    }
    return lines
}

// Function to check if a line is within the bounds of the canvas
private fun lineBound(xStartBound: Float, xEndBound: Float, yStartBound: Float,
                         yEndBound: Float, line: Line): Boolean {
    return line.start.x in xStartBound..xEndBound &&
            line.start.y >= yStartBound && line.start.y <= yEndBound &&
            line.end.x >= xStartBound && line.end.x <= xEndBound &&
            line.end.y >= yStartBound && line.end.y <= yEndBound
}

// Define Line
data class Line(
    val start: Offset,
    val end: Offset
)