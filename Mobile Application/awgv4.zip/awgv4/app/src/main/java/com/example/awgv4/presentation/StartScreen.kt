package com.example.awgv4.presentation

import android.content.res.Configuration
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.awgv4.R
import com.example.awgv4.domain.chat.BluetoothDevice
import kotlinx.coroutines.delay

val buttonTextSize = 28.sp
const val MCU_ADDRESS = "C4:DD:57:8C:B1:72"

/** Displays the app logo */
@Composable
private fun AppIcon() {
    val image = painterResource(R.drawable.awg_icon)

    val configuration = LocalConfiguration.current
    val imageSize = when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> 152.dp
        else -> 180.dp
    }
    Image(
        painter = image,
        contentDescription = null,
        modifier = Modifier
            .clip(CircleShape)
            .size(imageSize)
            .padding(vertical = 16.dp)
            .background(MaterialTheme.colorScheme.secondaryContainer)
    )
}

/** Shown when the application is scanning for devices
 * @param state : Used to track the current Bluetooth state
 */
@Composable
private fun ScanScreen(state: BluetoothUiState) {
    Text(
        text = stringResource(R.string.start_subtitle_wait),
        fontStyle = FontStyle.Italic,
        fontSize = 32.sp,
        color = MaterialTheme.colorScheme.onSurface
    )
    Spacer(modifier = Modifier.height(95.dp))
    CircularProgressIndicator(strokeWidth = 8.dp, modifier = Modifier.size(140.dp))
    Spacer(modifier = Modifier.height(12.dp))
    val isConnecting =
        if (state.isConnecting) { stringResource(R.string.bt_connecting) }
        else { stringResource(R.string.bt_scanning) }
    Text(
        text = isConnecting,
        fontSize = 28.sp,
        color = MaterialTheme.colorScheme.onSurface
    )
}

/** Shown when the application is connected or skipped connection
 * @param state : Used to track the current Bluetooth state
 */
@Composable
private fun ConnectionScreen(state: BluetoothUiState) {
    val isConnected =
        if (state.isConnected) { stringResource(R.string.start_title_connected) }
        else { stringResource(R.string.start_title_disconnected) }
    Text(
        text = isConnected,
        fontWeight = FontWeight.Bold,
        fontSize = 44.sp,
        color = MaterialTheme.colorScheme.onSurface
    )
    Spacer(modifier = Modifier.height(8.dp))
    Text(
        text = stringResource(R.string.start_subtitle_mode),
        fontStyle = FontStyle.Italic,
        fontSize = 32.sp,
        color = MaterialTheme.colorScheme.onSurface
    )
}

@Composable
fun StartScreen (
    navController: NavController,
    state: BluetoothUiState,
    onStartScan: () -> Unit,
    onStopScan: () -> Unit,
    onDeviceClick: (BluetoothDevice) -> Unit,
    skipScreen: Boolean
) {
    val configuration = LocalConfiguration.current
    val isLandscape = when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> true
        else -> false
    }

    val context = LocalContext.current

    // Determines if user skipped connection screen
    var skipConnect by remember { mutableStateOf(skipScreen) }

    // Check if device is scanning
    var isScanning by remember { mutableStateOf(false) }
    var tryToConnect by remember { mutableStateOf(false) }
    LaunchedEffect(isScanning) {
        if (isScanning) {
            delay(3000)
            tryToConnect = true
        }
    }

// Check if tryToConnect is true attempt to pair with the device
    if (tryToConnect) {
        onStopScan()
        val deviceToPair = state.scannedDevices.find { it.address == MCU_ADDRESS }
        if (deviceToPair != null) {
            onDeviceClick(deviceToPair)
        } else {
            Toast.makeText(context, R.string.bt_fail, Toast.LENGTH_SHORT).show()
        }
        isScanning = false
        tryToConnect = false
    }
    if (isLandscape) {
        Row (
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .background(MaterialTheme.colorScheme.surface)
                .padding(36.dp)
        ){
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                AppIcon()
                val title = if (state.isConnected) {
                    stringResource(R.string.start_title_connected)
                } else if (skipConnect) {
                    stringResource(R.string.start_title_disconnected)
                } else {
                    stringResource(R.string.start_title_greeting)
                }
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 40.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val subtitle = if (isScanning) {
                    stringResource(R.string.start_subtitle_wait)
                }else {
                    stringResource(R.string.start_subtitle_connect)
                }

                if (!state.isConnected && !skipConnect) {
                    Text(
                        text = subtitle,
                        fontStyle = FontStyle.Italic,
                        fontSize = 28.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (!state.isConnected) {
                    Spacer(Modifier.height(24.dp))
                }

                if (state.isConnected || skipConnect) {
                    SelectModeButtons(state, navController, R.string.sine)
                    SelectModeButtons(state, navController, R.string.triangle)
                    SelectModeButtons(state, navController, R.string.square)
                }

                else {
                    if (isScanning || state.isConnecting) {
                        CircularProgressIndicator(
                            strokeWidth = 8.dp, modifier = Modifier.size(140.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        val isConnecting =
                            if (state.isConnecting) { stringResource(R.string.bt_connecting) }
                            else { stringResource(R.string.bt_scanning) }
                        Text(
                            text = isConnecting,
                            fontSize = 26.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    else {
                        ElevatedButton(
                            onClick = { onStartScan(); isScanning = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            ),
                            shape = CircleShape,
                            elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
                            modifier = Modifier.size(180.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.start_button_connect),
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontSize = 34.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(12.dp))
                if (state.isConnected || skipConnect) {
                    SelectModeButtons(state, navController, R.string.sawtooth)
                    SelectModeButtons(state, navController, R.string.freehand)
                    if (!state.isConnected) {
                        Spacer(modifier = Modifier.height(16.dp))
                        ElevatedButton(
                            onClick = { onStartScan(); skipConnect = false; isScanning = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.tertiaryContainer
                            ),
                            elevation = ButtonDefaults.elevatedButtonElevation(4.dp),
                        ) {
                            Text(
                                text = stringResource(R.string.start_button_connect),
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                fontSize = buttonTextSize,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
                else {
                    ElevatedButton(
                        onClick = { skipConnect = true; isScanning = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer
                        ),
                        elevation = ButtonDefaults.elevatedButtonElevation(4.dp),
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "Skip\nConnection",
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            fontSize = buttonTextSize,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            lineHeight = 28.sp
                        )
                    }
                }
            }
        }
    }
    else {
        Column (
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp)
        ){
            AppIcon()
            Spacer(modifier = Modifier.height(8.dp))
            if (state.isConnected || skipConnect) {
                ConnectionScreen(state = state)
                Spacer(modifier = Modifier.height(12.dp))
                SelectModeButtons(state, navController, R.string.sine)
                SelectModeButtons(state, navController, R.string.triangle)
                SelectModeButtons(state, navController, R.string.square)
                SelectModeButtons(state, navController, R.string.sawtooth)
                SelectModeButtons(state, navController, R.string.freehand)
                // Show Optional Connect Button
                if (skipConnect) {
                    Spacer(modifier = Modifier.height(54.dp))
                    ElevatedButton(
                        onClick = { onStartScan(); skipConnect = false; isScanning = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer
                        ),
                        elevation = ButtonDefaults.elevatedButtonElevation(4.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.start_button_connect),
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            fontSize = buttonTextSize,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            else {
                Text(
                    text = stringResource(R.string.start_title_greeting),
                    fontWeight = FontWeight.Bold,
                    fontSize = 42.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))
                // Show Loading Wheel
                if (state.isConnecting || isScanning) { ScanScreen(state = state) }
                // Show Connect Button
                else {
                    Text(
                        text = stringResource(R.string.start_subtitle_connect),
                        fontStyle = FontStyle.Italic,
                        fontSize = 32.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(88.dp))
                    ElevatedButton(
                        onClick = { onStartScan(); isScanning = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        shape = CircleShape,
                        elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
                        modifier = Modifier.size(192.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.start_button_connect),
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(174.dp))
                // Skip Connection Button
                ElevatedButton(
                    onClick = { skipConnect = true; isScanning = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer
                    ),
                    elevation = ButtonDefaults.elevatedButtonElevation(4.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.start_button_skip),
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        fontSize = buttonTextSize,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

/** Buttons used to select wave
 * @param state : Used to track the current Bluetooth state
 * @param navController : Used to navigate between various screens
 * @param mode : Passes the mode that was selected
 */
@Composable
private fun SelectModeButtons (
    state: BluetoothUiState,
    navController: NavController,
    @StringRes mode: Int
) {
    val configuration = LocalConfiguration.current
    val buttonWidth = when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> 200.dp
        else -> 400.dp
    }
    val buttonSpace = if (state.isConnected) { 24.dp } else { 16.dp }
    ElevatedButton(
        onClick = { navController.navigate("${Screen.AwgApp.route}/${mode}") },
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        elevation = ButtonDefaults.elevatedButtonElevation(4.dp),
        modifier = Modifier
            .width(buttonWidth)
            .padding(horizontal = 16.dp, vertical = buttonSpace)
    ) {
        Text(stringResource(mode),
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontSize = buttonTextSize,
            fontWeight = FontWeight.SemiBold
        )
    }
}
