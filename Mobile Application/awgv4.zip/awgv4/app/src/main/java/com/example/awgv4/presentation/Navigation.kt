package com.example.awgv4.presentation

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.awgv4.AwgApp
import com.example.awgv4.presentation.components.DeviceScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Navigation() {
    val navController = rememberNavController()

    val viewModel = hiltViewModel<BluetoothViewModel>()
    val state by viewModel.state.collectAsState()

    NavHost(navController = navController, startDestination = "${Screen.StartScreen.route}/{skip}"){
        composable(
            route = "${Screen.StartScreen.route}/{skip}",
            arguments = listOf(navArgument(name = "skip") { type = NavType.BoolType })
        ){
            StartScreen(
                navController = navController,
                state = state,
                onStartScan = viewModel::startScan,
                onStopScan = viewModel::stopScan,
                onDeviceClick = viewModel::connectToDevice,
                skipScreen = it.arguments!!.getBoolean("skip")
            )
        }

        composable(
            route = "${Screen.AwgApp.route}/{mode}",
            arguments = listOf(navArgument(name = "mode") { type = NavType.IntType })
        ){
            AwgApp(
                navController = navController,
                state = state,
                onStartScan = viewModel::startScan,
                onStopScan = viewModel::stopScan,
                onSendData = viewModel::sendData,
                onDeviceClick = viewModel::connectToDevice,
                selectedMode = it.arguments!!.getInt("mode")
            )
        }

        composable(
            route = "${Screen.BluetoothScreen.route}/{mode}",
            arguments = listOf(navArgument(name = "mode") { type = NavType.IntType })
        ){
            DeviceScreen(
                state = state,
                navController = navController,
                onStartScan = viewModel::startScan,
                onStopScan = viewModel::stopScan,
                onDeviceClick = viewModel::connectToDevice,
                previousMode = it.arguments!!.getInt("mode"),
            )
        }
    }
}

sealed class Screen(val route:String){
    object StartScreen:Screen("start_screen")
    object AwgApp:Screen("awg_app")
    object BluetoothScreen:Screen("bluetooth_screen")
}