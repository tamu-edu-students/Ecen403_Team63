package com.example.awgv4

import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.geometry.Offset
import co.yml.charts.common.model.Point
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.*

object FunctionList {

    private const val MAX_PLOT_POINTS = 655
    private const val FREQ_SCALE = 10
    private const val EPSILON = 1e-6
    private const val V_REF = 10
    private const val DAC = 32767
    private const val STOP_VALUE = "FFFF"

    /** Calculates the y-pos (voltage) for each wave function:
     * Sine Wave | Triangle Wave | Square Wave | Sawtooth Wave */
    private fun sinePos(time:Double, frequency:Double, amplitude:Double, offset:Double): Double
    { return amplitude * sin(2 * Math.PI * frequency * time) + offset }
    private fun trianglePos(time:Double, frequency:Double, amplitude:Double, offset:Double): Double
    { return ((2*amplitude)/Math.PI) * asin(sin(2*Math.PI*frequency*time)) + offset }
    private fun squarePos(time:Double, frequency:Double, amplitude:Double, offset:Double): Double
    { return amplitude*(2*(2*floor(frequency*time)-floor(2*frequency*time))+1)+offset }
    private fun sawtoothPos(time:Double, frequency:Double, amplitude:Double, offset:Double): Double
    { return amplitude * (2*((time*frequency)-floor(0.5+(time*frequency)))) + offset }

    /** Converts voltage values into their equivalent DAC value */
    fun convertDoubleToDACValue(voltage: Double): Int
    {
        val dacValue = (((voltage/V_REF)+1) * DAC)
        return dacValue.roundToInt()
    }

    /** Converts DAC values into their HEX equivalent */
    fun dacToHex(decimal: Int): String {
        var hexString = Integer.toHexString(decimal)
        // Pad w/ zeros to ensure 4 hex digits
        while (hexString.length < 4) {
            hexString = "0$hexString"
        }
        return hexString
    }

    /** Turn DAC Values into a list of strings that will be exported to the MCU
     * @param graphDataPoints : Data points that represent the graph
     * @param channel : Set to true for channel 1 export, false for channel 2
     */
    // TODO: Channel Select, Period Value, Stop Value
    fun prepDacData(graphDataPoints: Array<Pair<Double, Double>>, channel: Boolean): List<String> {
        val strings = mutableListOf<String>()
        val stringBuilder = StringBuilder()
        var count = 1
        // val period = graphDataPoints.last().first
        // val numOfPoints = graphDataPoints.size
        if (channel) {
            Log.d("prepDacData", "CH1")
            // stringBuilder.append("CH1\n")
        } else {
            Log.d("prepDacData", "CH2")
            // stringBuilder.append("aa55aa55")
        }
        //stringBuilder.append("${period/numOfPoints}\n")    // "Time-step: ${period/numOfPoints}\n"
        for ((_, y) in graphDataPoints) {
            val dacValue = convertDoubleToDACValue(y)
            val hexValue = dacToHex(dacValue)
            //Log.d("prepDacData", hexValue)
            stringBuilder.append(hexValue)    // "$count: $dacValue\n"
            count++
            // Check size and add to the list if size is around 0.5kB
            if (stringBuilder.length >= 512) {
                strings.add(stringBuilder.toString())
                stringBuilder.clear()
            }
        }
        stringBuilder.append(STOP_VALUE)
        if (stringBuilder.isNotEmpty()) {
            strings.add(stringBuilder.toString())
        }
        // Log.d("PrepDacData", strings.size.toString())
        return strings
    }

    /** Produce plot points for each wave function
     * @param frequency : Duration of the wave
     * @param amplitude : Height of the wave
     * @param offset : Sets the starting y-axis value
     * @param points : Number of points in the wave
     * @param mode : Which wave function is being produced
     */
    suspend fun generateWavePlot(
        frequency: Double,
        amplitude: Double,
        offset: Double,
        points: Int,
        mode: Int
    ): List<Point> {
        return withContext(Dispatchers.Default) {
            val plotPoints = if (points > MAX_PLOT_POINTS) MAX_PLOT_POINTS else points
            val dataPoints = mutableListOf<Point>()
            //x-axis, time, step size
            val step = 1.0 / ((plotPoints - 1) * frequency)
            var time = 0.0

            repeat(plotPoints)
            {
//Calculate each data point position
                val position = when (mode)
                {
                    R.string.sine -> sinePos(time, frequency, amplitude, offset)
                    R.string.triangle -> trianglePos(time, frequency, amplitude, offset)
                    R.string.square -> squarePos(time, frequency, amplitude, offset)
                    R.string.sawtooth -> sawtoothPos(time, frequency, amplitude, offset)
                    else -> squarePos(time, frequency, amplitude, offset)
                }
//Add time and position values to dataPoints as a Point(x,y)
                dataPoints.add(Point((time * (frequency * FREQ_SCALE)).toFloat(), position.toFloat()))
                time += step
            }
            dataPoints
        }
    }

    /** Produce download data points for wave functions
     * @param frequency : Duration of the wave
     * @param amplitude : Height of the wave
     * @param offset : Sets the starting y-axis value
     * @param points : Number of points in the wave
     * @param wave : Which wave function is being produced
     */
    suspend fun generateWaveData(
        frequency: Double,
        amplitude: Double,
        offset: Double,
        points: Int,
        wave: Int
    ): Array<Pair<Double, Double>> {
        return withContext(Dispatchers.Default) {
            val dataPoints = Array(points) { Pair(0.0, 0.0) }
            val step = 1.0 / ((points - 1) * frequency)
            var time = 0.0
            var numberOfPoints = 0

            repeat(points) {
                val voltage = when (wave) {
                    R.string.sine -> sinePos(time, frequency, amplitude, offset)
                    R.string.triangle -> trianglePos(time, frequency, amplitude, offset)
                    R.string.square -> squarePos(time, frequency, amplitude, offset)
                    R.string.sawtooth -> sawtoothPos(time, frequency, amplitude, offset)
                    else -> return@withContext dataPoints
                }
                dataPoints[it] = Pair(time, voltage)
                time += step
                numberOfPoints++
            }
            dataPoints
        }
    }

    /** Lowers the number of points in the user drawn line list
     * @param userPoints : User inputted points
     * @param linePoints : Number of points in the drawn lines list
     * @param longList : Original drawn line list
     */
    private fun lowerFreehandPoints(
        userPoints: Int, linePoints: Int, longList: List<Line>
    ): List<Line> {
        var firstLine = 0
        var secondLine = 1
        var pointsInList = linePoints

        // Save original list for shortening
        val shorterList = mutableStateListOf<Line>()
        shorterList.addAll(longList)

        // Reduce line list until it matches user desired points
        while (userPoints < pointsInList) {
            // If the end of the list is reached, reset to the first two lines
            if (firstLine == shorterList.size || secondLine == shorterList.size) {
                firstLine = 0; secondLine = 1
            }
            // Create a new line using the start and end of two lines
            val newLineStart = shorterList[firstLine].start
            val newLineEnd = shorterList[secondLine].end
            // Removes first two lines
            shorterList.removeAt(firstLine)
            shorterList.removeAt(firstLine)
            // Add new combined line
            shorterList.add(firstLine, Line(newLineStart, newLineEnd))
            // Move to the next two lines after the created line
            firstLine++
            secondLine++
            // Update new number of points
            pointsInList = shorterList.size + 1
        }
        return shorterList
    }

    /** Raises the number of points in the user drawn line list
     * @param userPoints : User inputted points
     * @param linePoints : Number of points in the drawn lines list
     * @param shortList : Original drawn line list
     */
    private fun raiseFreehandPoints(
        userPoints: Int, linePoints: Int, shortList: List<Line>
    ): List<Line> {
        var originalLine = 0
        var pointsInList = linePoints
        // Save original list for lengthening
        val longerList = mutableStateListOf<Line>()
        longerList.addAll(shortList)
        //Increase line list until it matches user desired points
        while (userPoints > pointsInList) {
            // If the end of the list is reached, reset to the first line
            if (originalLine == longerList.size) { originalLine = 0 }
            // Establish two new lines start and end point
            val firstLineStart = longerList[originalLine].start
            val secondLineEnd = longerList[originalLine].end
            // Calculate point where the new two lines will meet
            val originalMidpoint = midpoint(
                longerList[originalLine].start.x, longerList[originalLine].end.x,
                longerList[originalLine].start.y, longerList[originalLine].end.y
            )
            // Removes original line and replaces it with the two new lines
            longerList.removeAt(originalLine)
            longerList.addAll(originalLine, listOf(Line(firstLineStart, originalMidpoint),
                Line(originalMidpoint, secondLineEnd)))
            // Move to the next line after the two created lines
            originalLine += 2
            // Update new number of points
            pointsInList = longerList.size + 1
        }
        return longerList
    }

    /** Converts each input value from its Offset value into its wave graph value
     * @param lines : List containing all drawn lines
     * @param frequency : User Inputted Frequency
     * @param amplitude : User Inputted Amplitude
     * @param offset : User Inputted Offset
     * @param points : User Inputted Points
     * @param isLandscape : Stores Current Orientation
     */
    suspend fun convertFreehandPoints(
        lines: List<Line>,
        frequency: Double,
        amplitude: Double,
        offset: Double,
        points: Int,
        isLandscape: Boolean
    ): Array<Pair<Double, Double>> {
        return withContext(Dispatchers.Default) {
            var linesPoints = lines.size + 1
            val finalLinesList = if (points < linesPoints) {
                lowerFreehandPoints(points, linesPoints, lines)
            } else if (points > linesPoints) {
                raiseFreehandPoints(points, linesPoints, lines)
            } else {
                lines
            }
            linesPoints = finalLinesList.size + 1

            // Assign Input Value Bounds Based on Orientation
            val minInputX: Float
            val minInputY: Float
            val maxInputX: Float
            val maxInputY: Float
            if (!isLandscape) {
                minInputX = PORTRAIT_X_START_BOUND; minInputY = PORTRAIT_Y_START_BOUND
                maxInputX = PORTRAIT_X_END_BOUND; maxInputY = PORTRAIT_Y_END_BOUND
            }
            else {
                minInputX = LANDSCAPE_X_START_BOUND; minInputY = LANDSCAPE_Y_START_BOUND
                maxInputX = LANDSCAPE_X_END_BOUND; maxInputY = LANDSCAPE_Y_END_BOUND
            }
            // Variables needed to convert offset
            val period = 1/frequency
            val maxAmp = abs(amplitude) + offset
            val minAmp = offset - abs(amplitude)

            // Convert points from Offset to Double
            val linesDataPoints = Array(linesPoints) { Pair(0.0, 0.0) }
            for ((currentLine, line) in finalLinesList.withIndex()) {
                val startTime = convertOffsetToDouble(
                    line.start.x, minInputX, maxInputX, EPSILON, period
                )
                val startVoltage = -1 * convertOffsetToDouble(
                    line.start.y, minInputY, maxInputY, minAmp, maxAmp
                )
                linesDataPoints[currentLine] = Pair(startTime, startVoltage)
            }
            // Convert final point
            val endTime = convertOffsetToDouble(
                lines.last().end.x, minInputX, maxInputX, EPSILON, period
            )
            val endVoltage = -1 * convertOffsetToDouble(
                lines.last().end.y, minInputY, maxInputY, minAmp, maxAmp
            )
            // Add final point to array
            linesDataPoints[linesDataPoints.size-1] = Pair(endTime, endVoltage)
            // Return array
            linesDataPoints
        }
    }

    /** Converts each input value from its Offset value into its wave graph value
     * @param inputVal : Original Value
     * @param minInput : Minimum value of original input
     * @param maxInput : Maximum value of original input
     * @param minOutput : Minimum value of new value range
     * @param maxOutput : Maximum value of new value range
     */
    private fun convertOffsetToDouble(
        inputVal: Float, minInput: Float, maxInput: Float, minOutput: Double, maxOutput: Double
    ): Double {
        return minOutput + (inputVal - minInput) * ((maxOutput - minOutput) / (maxInput - minInput))
    }

    private fun midpoint(xStart: Float, xEnd: Float, yStart: Float, yEnd: Float): Offset {
        return Offset((xStart+xEnd)/2, (yStart+yEnd)/2)
    }
}