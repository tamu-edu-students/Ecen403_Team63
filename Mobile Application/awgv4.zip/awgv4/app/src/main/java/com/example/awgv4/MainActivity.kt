package com.example.awgv4

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import co.yml.charts.common.model.Point
import com.example.awgv4.FunctionList.convertFreehandPoints
import com.example.awgv4.FunctionList.generateWaveData
import com.example.awgv4.FunctionList.generateWavePlot
import com.example.awgv4.FunctionList.prepDacData
import com.example.awgv4.domain.chat.BluetoothDevice
import com.example.awgv4.presentation.BluetoothUiState
import com.example.awgv4.presentation.MCU_ADDRESS
import com.example.awgv4.presentation.Navigation
import com.example.awgv4.presentation.Screen
import com.example.awgv4.ui.theme.Awgv4Theme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

@AndroidEntryPoint
@ExperimentalMaterial3Api
class MainActivity : ComponentActivity() {

    private val bluetoothManager by lazy {
        applicationContext.getSystemService(BluetoothManager::class.java)
    }
    private val bluetoothAdapter by lazy {
        bluetoothManager?.adapter
    }

    private val isBluetoothEnabled: Boolean
        get() = bluetoothAdapter?.isEnabled == true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val enableBluetoothLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { /*Not needed */ }

        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { perms ->
            val canEnableBluetooth =
                perms[Manifest.permission.BLUETOOTH_CONNECT] == true
            if(canEnableBluetooth && !isBluetoothEnabled) {
                enableBluetoothLauncher.launch(
                    Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                )
            }
           /* val canDiscoverDevice =
                perms[Manifest.permission.BLUETOOTH_ADVERTISE] == true
            if(canDiscoverDevice) {
                enableBluetoothLauncher.launch(
                    Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                )
            }*/
        }

        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE,
            )
        )

        setContent {
            Awgv4Theme {
                // A surface container using the 'background' color from the theme
                //val viewModel = hiltViewModel<BluetoothViewModel>()
                //val state by viewModel.state.collectAsState()

                /*LaunchedEffect(key1 = state.errorMessage) {
                    state.errorMessage?.let { message ->
                        Toast.makeText(
                            applicationContext,
                            message,
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }*/

                /*LaunchedEffect(state.isConnected) {
                    if(state.isConnected) {
                        Toast.makeText(
                            applicationContext,
                            R.string.bt_connected,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    else {
                        Toast.makeText(
                            applicationContext,
                            "You're disconnected!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }*/

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Navigation()
                }
            }
        }
    }
}

@ExperimentalMaterial3Api
@Composable
fun AwgApp(
    navController: NavController,
    state: BluetoothUiState,
    onStartScan: () -> Unit,
    onStopScan: () -> Unit,
    onSendData: (String) -> Unit,
    onDeviceClick: (BluetoothDevice) -> Unit,
    @StringRes selectedMode: Int
) {
    val coroutineScope = rememberCoroutineScope()

    var exportCancelled by remember { mutableStateOf(false) }

    // Used for displaying toasts
    val context = LocalContext.current
    var wasToastDisplayed by remember { mutableStateOf(false) }
    fun displayToast(toastMessage: Int) {
        Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show()
    }

    // Used to display progress bar
    var loading by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var useIndeterminate by remember { mutableStateOf(false) }
    LaunchedEffect(state.isConnected) {
        if (!state.isConnected) {
            if (loading) {
                displayToast(R.string.bt_export_loss)
                loading = false
                progress = 0f
                exportCancelled = true
            }
            else { displayToast(R.string.bt_disconnected) }
        }
        else { displayToast(R.string.bt_connected) }
    }

//Check Phone Orientation
    val configuration = LocalConfiguration.current
    val isLandscape = when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> true
        else -> false
    }

// Freehand Variables
    var linesData = emptyList<Line>()
    var clearLines by remember { mutableStateOf(false) }

// Buttons Variables
    var modeTitle by remember { mutableIntStateOf(selectedMode) }
    var modeExpanded by remember { mutableStateOf(false) }
    var settingExpanded by remember { mutableStateOf(false) }

// Frequency Input
    var frequencyInput by remember { mutableStateOf("100") }
    val validFreq by remember {
        derivedStateOf { validateDouble(frequencyInput, MIN_FREQ, MAX_FREQ, INVALID_NUM) }
    }
    val frequency = if (validFreq) frequencyInput.toDoubleOrNull() ?: MIN_FREQ else MIN_FREQ
    @Composable
    fun frequencyTextField(modifier: Modifier) {
        UserTextField(
            label = R.string.freq,
            placeholder = R.string.freq_range,
            value = frequencyInput,
            onValueChange = { newFreq ->
                frequencyInput = when {
                    newFreq.length == 1 && newFreq[0] == '0' -> {
                        // Input consists of only one character, which is '0'
                        "0"
                    }
                    newFreq.startsWith("0") && !newFreq.matches("0\\..*".toRegex()) -> {
                        // Input starts with zero and is not a decimal number, remove the leading zero
                        newFreq.substring(1)
                    }
                    else -> {
                        // Input is valid, assign it to offsetInput
                        newFreq
                    }
                }
            },
            isError = !validFreq,
            modifier = modifier
        )
    }

// Amplitude Input
    var amplitudeInput by remember { mutableStateOf("1") }
    val validAmp by remember { derivedStateOf { validateDouble(amplitudeInput, MIN_Y_VALUE,
        MAX_Y_VALUE, INVALID_AMP) } }
    val amplitude = if (validAmp) amplitudeInput.toDoubleOrNull() ?: 0.0 else 0.0
    @Composable
    fun amplitudeTextField(modifier: Modifier) {
        UserTextField(
            label = R.string.amp,
            placeholder = R.string.amp_range,
            value = amplitudeInput,
            onValueChange = { newAmp ->
                amplitudeInput = when {
                    newAmp.length == 1 && newAmp[0] == '0' -> {
                        // Input consists of only one character, which is '0'
                        "0"
                    }
                    newAmp.startsWith("0") && !newAmp.matches("0\\..*".toRegex()) -> {
                        // Input starts with zero and is not a decimal number, remove the leading zero
                        newAmp.substring(1)
                    }
                    else -> {
                        // Input is valid, assign it to offsetInput
                        newAmp
                    }
                }
            },
            isError = !validAmp,
            modifier = modifier
        )
    }

// Offset Input
    var offsetInput by remember { mutableStateOf("0") }
    val maxAllowedOffset = MAX_Y_VALUE - abs(amplitude)
    val minAllowedOffset = MIN_Y_VALUE + abs(amplitude)
    val validOff by remember(amplitude) { derivedStateOf { validateDouble(offsetInput,
        minAllowedOffset, maxAllowedOffset, INVALID_NUM) } }
    val offset = if (validOff) offsetInput.toDoubleOrNull() ?: 0.0 else 0.0
    @Composable
    fun offsetTextField(modifier: Modifier) {
        UserTextField(
            label = R.string.offset,
            placeholder = R.string.offset_range,
            value = offsetInput,
            onValueChange = { newOff ->
                offsetInput = when {
                    newOff.length == 1 && newOff[0] == '0' -> {
                        // Input consists of only one character, which is '0'
                        "0"
                    }
                    newOff.startsWith("0") && !newOff.matches("0\\..*".toRegex()) -> {
                        // Input starts with zero and is not a decimal number, remove the leading zero
                        newOff.substring(1)
                    }
                    else -> {
                        // Input is valid, assign it to offsetInput
                        newOff
                    }
                }
            },
            isError = !validOff,
            modifier = modifier
        )
    }

// Data Point Input
    var pointsInput by remember { mutableStateOf("100") }
    val validPoints by remember {
        derivedStateOf { validateInt(pointsInput, MIN_POINT, MAX_POINT) }
    }
    val points = if (validPoints) pointsInput.toIntOrNull() ?: MIN_POINT else MIN_POINT
    @Composable
    fun pointsTextField(modifier: Modifier) {
        UserTextField(
            label = R.string.points,
            placeholder = R.string.points_range,
            value = pointsInput,
            onValueChange = { newPoint ->
                pointsInput = if (newPoint.length == 1 && newPoint[0] == '0') {
                    // Input consists of only one character, which is '0'
                    "0"
                } else if (newPoint.length > 1 && newPoint.startsWith("00")) {
                    // Input starts with two or more zeros, remove all but one zero
                    "0" + newPoint.substring(1).trimStart('0')
                } else {
                    // Input is valid, assign it to frequencyInput
                    newPoint
                }
            },
            isError = !validPoints,
            modifier = modifier
        )
    }

// Error Checking
    val isErrorInInputs by remember {
        derivedStateOf { !(validFreq && validAmp && validOff && validPoints) }
    }
    fun isDataValid(selectedMode: Int): Boolean {
        return !(isErrorInInputs || ((selectedMode == R.string.freehand) && linesData.isEmpty()))
    }

    suspend fun prepExportData(currentMode: Int, channel: Boolean): List<String> {
        val graphPoints = when (currentMode) {
            R.string.freehand ->
                convertFreehandPoints(linesData, frequency, amplitude, offset, points, isLandscape)
            else ->
                generateWaveData(frequency, amplitude, offset, points, currentMode)
        }
        return prepDacData(graphPoints, channel)
    }

    // TODO: Delay
    suspend fun exportDataAsync(batchData: List<String>) {
        return withContext(Dispatchers.IO) {
            for ((index, point) in batchData.withIndex()) {
                if (!exportCancelled) {
                    onSendData(point)
                    progress = (index+1).toFloat() / batchData.size
                    delay(250)
                } else {
                    break
                }

            }
        }
    }

/** Start of app UI code, split into segments: Top Row, Graph, Bottom Text Fields */
    Column(
        modifier = Modifier
            .padding(start = 20.dp, end = 20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ){

/** Loading Bar */
        Box (
            modifier = Modifier
                .fillMaxWidth()
                .size(8.dp)
        ) {
            if (loading) {
                if (useIndeterminate) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

/** Top Button Row */
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
// Home Button
            val skip = true
            Icon(
                Icons.Default.Home,
                contentDescription = stringResource(R.string.home),
                modifier = Modifier
                    .size(32.dp)
                    .clickable { navController.navigate("${Screen.StartScreen.route}/$skip") }
            )

// Bluetooth Connection
            var isScanning by remember { mutableStateOf(false) }
            var tryToConnect by remember { mutableStateOf(false) }
            LaunchedEffect(isScanning) {
                if (isScanning) {
                    delay(3000)
                    tryToConnect = true
                }
            }

            if (tryToConnect) {
                onStopScan()
                isScanning = false
                val mcuDevice = state.scannedDevices.find { it.address == MCU_ADDRESS }
                if (mcuDevice != null) {
                    onDeviceClick(mcuDevice)
                    displayToast(R.string.bt_connecting)
                } else {
                    displayToast(R.string.bt_fail)
                }
                tryToConnect = false
            }

            Icon(
                if (state.isConnected) { painterResource(R.drawable.bluetooth_connected) }
                else if (isScanning || state.isConnecting) {
                    painterResource(R.drawable.bluetooth_searching)
                }
                else { painterResource(R.drawable.bluetooth_disabled) },
                contentDescription = stringResource(R.string.bt_icons),
                modifier = Modifier
                    .size(32.dp)
                    .clickable {
                        if (!state.isConnected) {
                            if (!isScanning) {
                                onStartScan()
                                isScanning = true
                                displayToast(R.string.bt_scanning)
                                wasToastDisplayed = false
                            } else {
                                if (!wasToastDisplayed) {
                                    displayToast(R.string.start_subtitle_wait)
                                    wasToastDisplayed = true
                                }
                            }
                        } else {
                            displayToast(R.string.bt_connected)
                        }
                    }
            )
// Mode Button
            Box {
                Button(
                    onClick = { modeExpanded = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                    ),
                    modifier = Modifier.width(128.dp)
                ) {
                    Text(
                        text = stringResource(modeTitle),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                DropdownMenu(
                    expanded = modeExpanded,
                    onDismissRequest = { modeExpanded = false }
                )
                {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.sine)) },
                        onClick = { modeTitle = R.string.sine; modeExpanded = false }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.triangle)) },
                        onClick = { modeTitle = R.string.triangle; modeExpanded = false }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.square)) },
                        onClick = { modeTitle = R.string.square; modeExpanded = false }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.sawtooth)) },
                        onClick = { modeTitle = R.string.sawtooth; modeExpanded = false }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.freehand)) },
                        onClick = { modeTitle = R.string.freehand; modeExpanded = false
                            if (!isLandscape) { displayToast(R.string.draw_toast) }
                        }
                    )
                }
            }

// Reset Button
            Icon(
                painterResource(R.drawable.undo),
                contentDescription = stringResource(R.string.undo),
                tint = if (modeTitle != R.string.freehand || loading) {
                    MaterialTheme.colorScheme.inverseSurface.copy(0.5f)
                } else {
                    MaterialTheme.colorScheme.inverseSurface
                },
                modifier = Modifier
                    .size(32.dp)
                    .clickable {
                        if (modeTitle == R.string.freehand && !loading) {
                            clearLines = true
                            coroutineScope.launch {
                                delay(500)
                                clearLines = false
                            }
                        }
                    }
            )

// Settings Button
            Box {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = stringResource(R.string.setting),
                    modifier = Modifier
                        .size(36.dp)
                        .clickable { settingExpanded = true }
                )
                DropdownMenu(
                    expanded = settingExpanded,
                    onDismissRequest = { settingExpanded = false })
                {
                    DropdownMenuItem(text = {
                        Text(
                            text = "Download",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp
                        )
                    },
                        onClick = {
                            if (loading) {
                                if (!wasToastDisplayed) {
                                    displayToast(R.string.start_subtitle_wait)
                                    wasToastDisplayed = true
                                }
                            }
                            else if (isDataValid(modeTitle)) {
                                loading = true
                                useIndeterminate = true
                                settingExpanded = false
                                wasToastDisplayed = false
                                coroutineScope.launch {
                                    val fileExt = ".csv"
                                    val fileName = when (modeTitle) {
                                        R.string.sine -> "SineData$fileExt"
                                        R.string.triangle -> "TriangleData$fileExt"
                                        R.string.square -> "SquareData$fileExt"
                                        R.string.sawtooth -> "SawtoothData$fileExt"
                                        else -> "FreehandData$fileExt"
                                    }
                                    val dataToDownload = if (modeTitle != R.string.freehand) {
                                        generateWaveData(
                                            frequency, amplitude, offset, points, modeTitle
                                        )
                                    } else {
                                        convertFreehandPoints(
                                            linesData, frequency, amplitude,
                                            offset, points, isLandscape
                                        )
                                    }
                                    writeToFile(fileName, dataToDownload)
                                    loading = false
                                    displayToast(R.string.file_download)
                                }
                            }
                            else { settingExpanded = false; displayToast(R.string.upload_error) }
                        }
                    )
                    // TODO: Channel 1
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = "Export: Ch.1",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp,
                                color = if (!state.isConnected) {
                                    MaterialTheme.colorScheme.inverseSurface.copy(0.5f)
                                } else {
                                    MaterialTheme.colorScheme.inverseSurface
                                }
                            )
                        },
                        onClick = {
                            if (loading) {
                                if (!wasToastDisplayed) {
                                    displayToast(R.string.start_subtitle_wait)
                                    wasToastDisplayed = true
                                }
                            }
                            else {
                                when {
                                    state.isConnected -> {
                                        if (isDataValid(modeTitle)) {
                                            loading = true
                                            useIndeterminate = false
                                            settingExpanded = false
                                            wasToastDisplayed = false
                                            exportCancelled = false
                                            coroutineScope.launch {
                                                val dataToExport = prepExportData(modeTitle, true)
                                                exportDataAsync(dataToExport)
                                                // If loop completes, reset loading UI
                                                progress = 0f
                                                loading = false
                                                displayToast(R.string.file_export)
                                            }
                                        }
                                        else { displayToast(R.string.upload_error) }
                                    }
                                    else -> { displayToast(R.string.connect_device) }
                                }
                            }
                        }
                    )
                    // TODO: Channel 2
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = "Export: Ch.2",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp,
                                color = if (!state.isConnected) {
                                    MaterialTheme.colorScheme.inverseSurface.copy(0.5f)
                                } else {
                                    MaterialTheme.colorScheme.inverseSurface
                                }
                            )
                        },
                        onClick = {
                            if (loading) {
                                if (!wasToastDisplayed) {
                                    displayToast(R.string.start_subtitle_wait)
                                    wasToastDisplayed = true
                                }
                            }
                            else {
                                when {
                                    state.isConnected -> {
                                        if (isDataValid(modeTitle)) {
                                            loading = true
                                            useIndeterminate = false
                                            settingExpanded = false
                                            wasToastDisplayed = false
                                            exportCancelled = false
                                            coroutineScope.launch {
                                                val dataToExport = prepExportData(modeTitle, false)
                                                exportDataAsync(dataToExport)
                                                // If loop completes, reset loading UI
                                                progress = 0f
                                                loading = false
                                                displayToast(R.string.file_export)
                                            }
                                        }
                                        else { displayToast(R.string.upload_error) }
                                    }
                                    else -> { displayToast(R.string.connect_device) }
                                }
                            }
                        }
                    )
                }
            }

        }

/** Wave Window */
        Row(
            modifier = Modifier,
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
// Y-Axis Title
            Text(
                text = stringResource(R.string.y_axis_title),
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier
                    .vertical()
                    .rotate(-90f)
                )
// Change wave window based on mode selection
            // TODO: Acting weird, triangle || sawtooth -> freehand, shifts graph
            val period = 1/frequency
            var waveData by remember { mutableStateOf(listOf(Point(0f,0f))) }
            // Calculate wave data off the main thread
            LaunchedEffect(frequency, amplitude, offset, points, modeTitle) {
                waveData = generateWavePlot(frequency, amplitude, offset, points, modeTitle)
            }
            if (modeTitle != R.string.freehand) {
                WaveGraph(modeTitle, period, waveData)
            } else {
                Box(contentAlignment = Alignment.TopEnd) {
                    WaveGraph(modeTitle, period, waveData)
                    linesData = drawFunction(clearLines, configuration)
                }
            }
        }
// X-Axis Title
        if (frequency < 1000) {
            Text(
                text = stringResource(R.string.x_axis_title_milli),
                color = MaterialTheme.colorScheme.tertiary
            )
        }
        else {
            Text(
                text = stringResource(R.string.x_axis_title_nano),
                color = MaterialTheme.colorScheme.tertiary
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        /** Text Fields */
        Row {
            frequencyTextField(modifier = Modifier.weight(TEXT_FIELD_WEIGHT))
            Spacer(modifier = Modifier.width(TEXT_FIELD_SPACER.dp))
            amplitudeTextField(modifier = Modifier.weight(TEXT_FIELD_WEIGHT))
// Landscape Orientation
            if (isLandscape) {
                Spacer(modifier = Modifier.width(TEXT_FIELD_SPACER.dp))
                offsetTextField(modifier = Modifier.weight(TEXT_FIELD_WEIGHT))
                Spacer(modifier = Modifier.width(TEXT_FIELD_SPACER.dp))
                pointsTextField(modifier = Modifier.weight(TEXT_FIELD_WEIGHT))
            }
        }
// Portrait Orientation
        if(!isLandscape) {
            Spacer(modifier = Modifier.height(TEXT_FIELD_SPACER.dp))
            Row {
                offsetTextField(modifier = Modifier.weight(TEXT_FIELD_WEIGHT))
                Spacer(modifier = Modifier.width(TEXT_FIELD_SPACER.dp))
                pointsTextField(modifier = Modifier.weight(TEXT_FIELD_WEIGHT))
            }
        }
    }
}