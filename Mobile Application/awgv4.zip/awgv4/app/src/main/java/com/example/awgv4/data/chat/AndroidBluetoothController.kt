package com.example.awgv4.data.chat

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.ContentValues.TAG
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.util.Log
import com.example.awgv4.domain.chat.BluetoothController
import com.example.awgv4.domain.chat.BluetoothDeviceDomain
import com.example.awgv4.domain.chat.ConnectionResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.*

@SuppressLint("MissingPermission")
class AndroidBluetoothController(
    private val context: Context
): BluetoothController {

    private val bluetoothManager by lazy {
        context.getSystemService(BluetoothManager::class.java)
    }
    private val bluetoothAdapter by lazy {
        bluetoothManager?.adapter
    }

    private var dataTransferService: BluetoothDataTransferService? = null

    private val _isConnected = MutableStateFlow(false)
    override val isConnected: StateFlow<Boolean>
        get() = _isConnected.asStateFlow()

    private val _scannedDevices = MutableStateFlow<List<BluetoothDeviceDomain>>(emptyList())
    override val scannedDevices: StateFlow<List<BluetoothDeviceDomain>>
        get() = _scannedDevices.asStateFlow()

    private val _pairedDevices = MutableStateFlow<List<BluetoothDeviceDomain>>(emptyList())
    override val pairedDevices: StateFlow<List<BluetoothDeviceDomain>>
        get() = _pairedDevices.asStateFlow()

    private val _errors = MutableSharedFlow<String>()
    override val errors: SharedFlow<String>
        get() = _errors.asSharedFlow()

    private val foundDeviceReceiver = FoundDeviceReceiver {device ->
        _scannedDevices.update { devices ->
            val newDevice = device.toBluetoothDeviceDomain()
            if(newDevice in devices) devices else devices + newDevice
        }
    }

    private val bluetoothStateReceiver = BluetoothStateReceiver { isConnected, bluetoothDevice ->
        if(bluetoothAdapter?.bondedDevices?.contains(bluetoothDevice) == true) {
            _isConnected.update { isConnected }
        } else {
            CoroutineScope(Dispatchers.IO).launch {
                _errors.emit("Can't connect to a non-paired device.")
            }
        }
    }
    //Location to store server socket
    private var currentServerSocket: BluetoothServerSocket? = null
    private var currentClientSocket: BluetoothSocket? = null

    init {
        updatePairedDevices()
        context.registerReceiver(
            bluetoothStateReceiver,
            IntentFilter().apply {
                addAction(BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED)
                addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
                addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            }
        )
    }

    /** SCAN FOR BLUETOOTH DEVICES */
    override fun startDiscovery() {
        if(!hasPermission(Manifest.permission.BLUETOOTH_SCAN)) {
            return
        }
        //Reset scannedDevices list and discovery scan
        _scannedDevices.value = emptyList()
        bluetoothAdapter?.cancelDiscovery()

        //Used to find scanned devices
        context.registerReceiver(
            foundDeviceReceiver,
            IntentFilter(BluetoothDevice.ACTION_FOUND)
        )

        updatePairedDevices()
        //Begins bluetooth discovery process
        bluetoothAdapter?.startDiscovery()
        Log.d("startDiscovery", "Scanning")
    }

    /** STOP SCANNING FOR BLUETOOTH DEVICES */
    override fun stopDiscovery() {
        if(!hasPermission(Manifest.permission.BLUETOOTH_SCAN)) {
            return
        }
        //Stop bluetooth scan
        bluetoothAdapter?.cancelDiscovery()
        Log.d("stopDiscovery", "Stopped Scanning")
    }

    /** START SERVER FOR BLUETOOTH CONNECTION */
    override fun startBluetoothServer(): Flow<ConnectionResult> {
        return flow {
            if(!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
                throw SecurityException("No BLUETOOTH_CONNECT permission")
            }

            // Start the server socket
            currentServerSocket = bluetoothAdapter?.listenUsingRfcommWithServiceRecord(
                "AWG",
                UUID.fromString(SERVICE_UUID)
            )

            var shouldLoop = true
            while(shouldLoop) {
                currentClientSocket = try {
                    currentServerSocket?.accept()
                } catch (e: IOException) {
                    Log.e("startBluetoothServer", "Socket's accept() method failed", e)
                    Log.d("startBluetoothServer", "CONNECTION FAILED")
                    shouldLoop = false
                    null
                }
                emit(ConnectionResult.ConnectionEstablished)
                Log.d("startBluetoothServer", "CONNECTION SUCCESSFUL")
                currentClientSocket?.let {
                    currentServerSocket?.close()
                    val service = BluetoothDataTransferService(it)
                    dataTransferService = service
                }
            }
        }.onCompletion {
            closeConnection()
        }.flowOn(Dispatchers.IO)
    }

    /** ATTEMPT CLIENT BLUETOOTH CONNECTION */
    override fun connectToDevice(device: BluetoothDeviceDomain): Flow<ConnectionResult> {
        return flow {
            if(!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
                throw SecurityException("No BLUETOOTH_CONNECT permission")
            }
            
            val remoteDevice = bluetoothAdapter?.getRemoteDevice(device.address)
            if (remoteDevice == null) {
                emit(ConnectionResult.Error("Device not found"))
                return@flow
            }

            // Initiate pairing if not already paired
            if (remoteDevice.bondState != BluetoothDevice.BOND_BONDED) {
                val pairingSuccessful = remoteDevice.createBond()
                if (!pairingSuccessful) {
                    emit(ConnectionResult.Error("Failed to pair with the device"))
                    //Log.d("connectToDevice", "FAILED TO PAIR")
                    return@flow
                } else {
                    //Log.d("connectToDevice", "PAIRING SUCCESSFUL")
                }
            }

            currentClientSocket = bluetoothAdapter
                ?.getRemoteDevice(device.address)
                ?.createRfcommSocketToServiceRecord(
                    UUID.fromString(SERVICE_UUID)
                )
            stopDiscovery()
            //Log.d("connectToDevice", device.address)

            currentClientSocket?.let { socket ->
                try {
                    socket.connect()
                    emit(ConnectionResult.ConnectionEstablished)
                    //Log.d("connectToDevice", "CONNECTION SUCCESSFUL")

                    BluetoothDataTransferService(socket).also {
                        dataTransferService = it
                    }

                    //trySendData(data)

                } catch(e: IOException) {
                    socket.close()
                    currentClientSocket = null
                    emit(ConnectionResult.Error("Connection was interrupted"))
                    Log.e(TAG, "CONNECTION WAS INTERRUPTED", e)
                    //Log.d("connectToDevice", "CONNECTION FAILED")
                }
            }
        }.onCompletion {
            //closeConnection()
        }.flowOn(Dispatchers.IO)
    }

    /** ATTEMPT TO SEND DATA AFTER CONNECTION */
    override suspend fun trySendData(data: String) {
        // Handles permission checking
        if(!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            throw SecurityException("No BLUETOOTH_CONNECT permission")
        }
        // Checks if connection established
        if (dataTransferService == null) {
            return
        }

        val byteData = data.toByteArray()
        dataTransferService?.sendData(byteData)

        //Log.d("trySendData", "DATA SENT:\n$data")
    }

    //Close connection between devices on connection lost
    override fun closeConnection() {
        currentClientSocket?.close()
        currentServerSocket?.close()
        currentClientSocket = null
        currentServerSocket = null
    }

    override fun release() {
        context.unregisterReceiver(foundDeviceReceiver)
        context.unregisterReceiver(bluetoothStateReceiver)
        closeConnection()
    }

    @SuppressLint("MissingPermission")
    private fun updatePairedDevices() {
        if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            return
        }
        bluetoothAdapter
            ?.bondedDevices
            ?.map { it.toBluetoothDeviceDomain() }
            ?.also { devices ->
                _pairedDevices.update { devices } }
    }

    private fun hasPermission(permission: String): Boolean {
        return context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        // Laptop UUID ("345F7087-5EC7-EA11-8105-842AFD6F90E4")
        // Desktop UUID ("0D9745D8-55FD-17C1-7427-244BFE994CCC")
        // ESP32 UUID ("00001101-0000-1000-8000-00805F9B34FB")
        const val SERVICE_UUID = "00001101-0000-1000-8000-00805F9B34FB"
    }
}