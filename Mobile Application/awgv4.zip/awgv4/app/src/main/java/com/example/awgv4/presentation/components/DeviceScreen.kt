package com.example.awgv4.presentation.components

import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.awgv4.domain.chat.BluetoothDevice
import com.example.awgv4.presentation.BluetoothUiState
import com.example.awgv4.presentation.Screen
import kotlinx.coroutines.delay

@Composable
fun BluetoothButtons(
    onClick: () -> Unit,
    buttonText: String,
    modifier: Modifier
) {
    Button(onClick = { onClick() },
        modifier = modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.inversePrimary,
            contentColor = MaterialTheme.colorScheme.inverseSurface
        )
    ) {
        Text(text = buttonText, fontSize = 24.sp)
    }
}

@Composable
fun DeviceScreen(
    state: BluetoothUiState,
    onStartScan: () -> Unit,
    onStopScan: () -> Unit,
    onDeviceClick: (BluetoothDevice) -> Unit,
    navController: NavController,
    @StringRes previousMode: Int,
) {

    var isScanning by remember { mutableStateOf(false) }

    // Used to trigger scan timer
    var scanSession by remember {
        mutableIntStateOf(0)
    }
    // On each new scan reset timer
    LaunchedEffect(scanSession) {
        if (isScanning) {
            delay(12000)
            isScanning = false
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()

    ) {
        Text(
            text = "Press 'Connect' to Begin",
            fontStyle = FontStyle.Italic,
            fontWeight = FontWeight.Bold,
            fontSize = 28.sp,
            modifier = Modifier.padding(16.dp)
        )

        if (!isScanning) {
            BluetoothButtons(
                onClick = {
                    onStartScan()
                    isScanning = true
                    scanSession++
                },
                buttonText = "Connect",
                modifier = Modifier.padding(16.dp)
            )
        } else {
            BluetoothButtons(onClick = { onStopScan(); isScanning = false; },
                buttonText = "Stop Scan",
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
/*
        Text(
            text = "Select 'ESP32-BT-Slave'",
            fontStyle = FontStyle.Italic,
            fontWeight = FontWeight.Bold,
            fontSize = 28.sp,
            modifier = Modifier.padding(16.dp)
        )

        BluetoothDeviceList(
            isScanning = isScanning,
            scannedDevices = state.scannedDevices,
            onClick = onDeviceClick,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        )
*/
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {

            /*
            START SCAN BUTTON

            if (!isScanning) {
                BluetoothButtons(onClick = { onStartScan(); isScanning = true; scanSession++ },
                    buttonText = "Start Scan", modifier = Modifier.weight(1f).padding(12.dp)
                )
            }

            STOP SCAN BUTTON

            BluetoothButtons(onClick = { onStopScan(); isScanning = false; },
                buttonText = "Stop Scan", modifier = Modifier.weight(1f)
            )
            */

            /** GRAPH SCREEN BUTTON */

            BluetoothButtons(onClick =
            { navController.navigate("${Screen.AwgApp.route}/${previousMode}") },
                buttonText = "Graph Screen", modifier = Modifier.weight(1f).padding(12.dp)
            )
        }
    }

    if (isScanning) {
        for (device in state.scannedDevices) {
            when {
                (device.name == "LAPTOP-ICBJ4DAC") -> {
                    onStopScan()
                    onDeviceClick(device)
                    isScanning = false

                }
            }
        }
    }

    if (state.isConnected) {
        navController.navigate("${Screen.AwgApp.route}/${previousMode}")
    }
}

@Composable
fun BluetoothDeviceList(
    isScanning: Boolean,
    scannedDevices: List<BluetoothDevice>,
    onClick: (BluetoothDevice) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
    ) {
        item {
            Row {
                if (isScanning) {
                    Text(
                        text = "Scanning",
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        modifier = Modifier.padding(16.dp)
                    )

                    CircularProgressIndicator(
                        modifier = Modifier
                            .size(30.dp)
                            .align(Alignment.CenterVertically)
                    )
                } else {
                    Text(
                        text = "Found Devices:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        modifier = Modifier.padding(16.dp)
                    )
                }
                Text(
                    text = "Scanning...",
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp,
                    modifier = Modifier.padding(16.dp)
                )
                if (isScanning) {
                    CircularProgressIndicator(
                        modifier = Modifier
                            .size(30.dp)
                            .align(Alignment.CenterVertically)
                    )
                }
            }
            Text(
                text = "Select 'ESP32-BT-Slave'",
                fontStyle = FontStyle.Italic,
                fontSize = 20.sp,
                modifier = Modifier.padding(start = 16.dp, bottom = 20.dp)
            )
        }
        items(scannedDevices) {device ->
            //"LAPTOP-ICBJ4DAC-ESP32-BT-Slave"
            if (device.name == "ESP32-BT-Slave") {
                Text(
                    text = device.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onClick(device) }
                        .padding(16.dp)
                )
            }
        }
    }
}